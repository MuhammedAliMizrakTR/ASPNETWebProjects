﻿using AriBilgiCoreEmptyMVC1.Models;
using Microsoft.AspNetCore.Mvc;

namespace AriBilgiCoreEmptyMVC1.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult merhaba()
        {
            return View();
        }

        //localhost:port/home/veri
        public IActionResult Veri()
        {
            Employee e = new Employee();
            e.FirstName = "Ali";
            e.LastName = "Yıldız";


            return View(e);
        }


        List<Employee> employees = new List<Employee>();

        public IActionResult Veriler()
        {
            Employee e = new Employee();
            e.FirstName = "Ali";
            e.LastName = "Yıldız";
            employees.Add(e);


            Employee e1 = new Employee();
            e1.FirstName = "Ayşe";
            e1.LastName = "Canlı";
            employees.Add(e1);


            Employee e2 = new Employee();
            e2.FirstName = "Mustafa";
            e2.LastName = "Can";
            employees.Add(e2);

            return View(employees);
        }



    }
}
