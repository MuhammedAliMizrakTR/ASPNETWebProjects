﻿using Microsoft.AspNetCore.Mvc;

namespace AriBilgiCoreEmptyMVC1.Controllers
{
    public class TestController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
