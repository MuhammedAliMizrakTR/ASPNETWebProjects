﻿namespace AriBilgiCoreEmptyMVC1.Models
{
    public class Employee
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

    }
}
