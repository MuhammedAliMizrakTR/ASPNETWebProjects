var builder = WebApplication.CreateBuilder(args);

//Servis tan�mlamalar� builder ile yap�l�r
builder.Services.AddControllersWithViews(); // MVC K�t�phanesini ekler


var app = builder.Build();

//middleware(ara katman) �al��ma zaman�nda uygulamaya eklenecek app ler 
//app.MapGet("/", () => "Hello World!");


app.UseRouting(); //rotalama �zelli�ini aktif et
app.UseStaticFiles(); //statik dosyalar� kullan�ma a�
app.UseHttpsRedirection(); //Https e y�nlendirme yap


//app.MapDefaultControllerRoute(); // default route ayar�

app.MapControllerRoute(
    name:"default",
    pattern:"{controller=Home}/{action=index}/{id?}");


app.Run();
